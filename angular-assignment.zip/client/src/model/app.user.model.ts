export class User{
    constructor(
    
        public userName:String,
        public password:String,
        public role:String,
        public email:String,     
        public dateTime:String
    ){}
}